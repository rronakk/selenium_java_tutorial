package com.toolsqa.interfaceexample;

public class DevLoginImplementation implements WebSiteInterface {

	@Override
	public boolean login(String un, String pw) {


		// Selenium Commands
		//1.  Opening Browser
		// Performing Login using Selenium
		
		// Validating Success
		
		return false;
	}

}
