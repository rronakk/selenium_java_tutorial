package com.toolsqa.interfaceexample;

public interface WebSiteInterface {

	public boolean login(String un, String pw);
	
}
