package com.toolsqa.javafundamentals;

public interface TestCase {

	public void setup();
	public void run();
	public void cleanup();
	
}
