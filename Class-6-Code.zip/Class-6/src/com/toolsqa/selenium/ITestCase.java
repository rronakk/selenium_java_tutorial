package com.toolsqa.selenium;

import org.openqa.selenium.WebDriver;

public interface ITestCase {
	
	void run(WebDriver driver);
	
}
